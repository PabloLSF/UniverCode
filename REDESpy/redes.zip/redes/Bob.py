import random

class Bob:
    def __init__(self, nome):
        self.nome=nome
        dano=0
        hp=19
        
      def int atackRapdo()
        int valor = random.range(1,3)
        return valor
    
    def int atackNomrl():
        int valor = random.range(1,5)
        return valor
  
    def int atackForte()
        int valor = random.range(1,9)
        return valor
    
    def int getDano():
        return dano   
    
    def String getPer():
        return per   

    def int rollDef():
        int valor = random.range(2,12)
        return valor

    def levarDano(int dano):
        self.hp=hp-dano;
        if hp<=0:
            return 0
        else:
            return 1;

